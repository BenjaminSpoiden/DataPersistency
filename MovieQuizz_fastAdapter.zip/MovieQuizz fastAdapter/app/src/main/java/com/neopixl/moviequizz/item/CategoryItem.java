package com.neopixl.moviequizz.item;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mikepenz.fastadapter.items.AbstractItem;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Category;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CategoryItem extends AbstractItem<CategoryItem, CategoryItem.CategoryItemViewHolder> {

    private Category category;
    private CategoryItemViewHolder viewHolder;

    public CategoryItem(Category category) {
        this.category = category;
    }

    public Category getCategory() {
        return category;
    }

    @Override
    public void bindView(CategoryItemViewHolder holder, List<Object> payloads) {
        super.bindView(holder, payloads);
        viewHolder = holder;
        viewHolder.update(category);
    }

    @Override
    public void unbindView(CategoryItemViewHolder holder) {
        super.unbindView(holder);

        holder.clear();
    }

    @NonNull
    @Override
    public CategoryItemViewHolder getViewHolder(View v) {
        return new CategoryItemViewHolder(v);
    }

    @Override
    public int getType() {
        return R.id.row_category_textView_name;
    }

    @Override
    public int getLayoutRes() {
        return R.layout.row_category;
    }

    public class CategoryItemViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.row_category_textView_name)
        TextView nameTextView;

        public CategoryItemViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }

        public void update(Category category){
            nameTextView.setText(category.getName());
        }

        public void clear(){
            nameTextView.setText(null);

        }
    }
}