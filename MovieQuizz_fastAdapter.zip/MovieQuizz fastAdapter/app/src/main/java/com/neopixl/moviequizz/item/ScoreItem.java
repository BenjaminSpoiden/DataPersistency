package com.neopixl.moviequizz.item;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mikepenz.fastadapter.items.AbstractItem;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Score;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ScoreItem extends AbstractItem<ScoreItem, ScoreItem.ScoreItemViewHolder> {

    private Score score;
    private ScoreItemViewHolder viewHolder;

    public ScoreItem(Score score) {
        this.score = score;
    }

    public Score getScore() {
        return score;
    }

    @Override
    public void bindView(ScoreItemViewHolder holder, List<Object> payloads) {
        super.bindView(holder, payloads);
        viewHolder = holder;
        viewHolder.update(score);
    }

    @Override
    public void unbindView(ScoreItemViewHolder holder) {
        super.unbindView(holder);

        holder.clear();
    }

    @NonNull
    @Override
    public ScoreItemViewHolder getViewHolder(View v) {
        return new ScoreItemViewHolder(v);
    }

    @Override
    public int getType() {
        return R.id.row_highscore_textView_name;
    }

    @Override
    public int getLayoutRes() {
        return R.layout.row_highscore;
    }

    public class ScoreItemViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.row_highscore_textView_name)
        TextView nameTextView;

        @BindView(R.id.row_highscore_textView_score)
        TextView scoreTextView;

        public ScoreItemViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        public void update(Score score){
            nameTextView.setText(score.getName());
            scoreTextView.setText(score.getScore() + " / " + score.getMaxScore());
        }

        public void clear(){
            nameTextView.setText(null);
            scoreTextView.setText(null);
        }
    }
}