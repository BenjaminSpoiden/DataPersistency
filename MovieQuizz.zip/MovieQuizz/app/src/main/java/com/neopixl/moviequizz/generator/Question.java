package com.neopixl.moviequizz.generator;

import android.os.Parcel;
import android.os.Parcelable;

public class Question implements Parcelable {
	
	private String sentence;
	private String answer1;
	private String answer2;
	private String answer3;
	private int correctAnswerNumber;
	
	/**
	 * @return the sentence
	 */
	public String getSentence() {
		return sentence;
	}
	/**
	 * @param sentence the sentence to set
	 */
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	/**
	 * @return the answer1
	 */
	public String getAnswer1() {
		return answer1;
	}
	/**
	 * @param answer1 the answer1 to set
	 */
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	/**
	 * @return the answer2
	 */
	public String getAnswer2() {
		return answer2;
	}
	/**
	 * @param answer2 the answer2 to set
	 */
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	/**
	 * @return the answer3
	 */
	public String getAnswer3() {
		return answer3;
	}
	/**
	 * @param answer3 the answer3 to set
	 */
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	/**
	 * @return the correctAnswerNumber
	 */
	public int getCorrectAnswerNumber() {
		return correctAnswerNumber;
	}
	/**
	 * @param correctAnswerNumber the correctAnswerNumber to set
	 */
	public void setCorrectAnswerNumber(int correctAnswerNumber) {
		this.correctAnswerNumber = correctAnswerNumber;
	}
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int arg1) {
		parcel.writeString(sentence);
		parcel.writeString(answer1);
		parcel.writeString(answer2);
		parcel.writeString(answer3);
		parcel.writeInt(correctAnswerNumber);

	}

	public static final Creator<Question> CREATOR
	= new Creator<Question>() {
		public Question createFromParcel(Parcel in) {
			Question question = new Question();
			question.setSentence(in.readString());
			question.setAnswer1(in.readString());
			question.setAnswer2(in.readString());
			question.setAnswer3(in.readString());
			question.setCorrectAnswerNumber(in.readInt());
			
			return question;
		}

		public Question[] newArray(int size) {
			return new Question[size];
		}
	};
	
}
