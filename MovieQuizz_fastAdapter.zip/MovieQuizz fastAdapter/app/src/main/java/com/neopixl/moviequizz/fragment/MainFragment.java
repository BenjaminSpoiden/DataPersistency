package com.neopixl.moviequizz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mikepenz.fastadapter.IAdapter;
import com.mikepenz.fastadapter.commons.adapters.FastItemAdapter;
import com.mikepenz.fastadapter.listeners.OnClickListener;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.item.CategoryItem;
import com.neopixl.moviequizz.model.Category;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static androidx.recyclerview.widget.RecyclerView.VERTICAL;

public class MainFragment extends Fragment {
    @BindView(R.id.fragment_main_listViewCategory)
    RecyclerView recyclerView = null;

    private int containerId;
    private FastItemAdapter<CategoryItem> adapter = new FastItemAdapter<>();
    private List<Category> categories = new ArrayList<>();

    public static MainFragment newInstance(List<Category> categories)
    {
        MainFragment fragment = new MainFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);
        fragment.categories.clear();
        fragment.categories.addAll(categories);

        for (Category category : categories){
            fragment.adapter.add(new CategoryItem(category));
        }

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        containerId = container.getId();
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        ButterKnife.bind(this, view);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), VERTICAL, false));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        getActivity().setTitle(R.string.app_name);
    }

    @Override
    public void onStart() {
        super.onStart();
        recyclerView.setAdapter(adapter);
        adapter.withOnClickListener((v, adapter, item, position) -> {
            QuestionFragment fragment = QuestionFragment.newInstance(item.getCategory());
            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
            fragmentTransaction.add(R.id.container, fragment);
            //Add to back stack the current fragment
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            return true;
        });
    }

    @OnClick(R.id.fragment_main_btnHighScores)
    public void onClick(View v) {
        ScoreFragment fragment = ScoreFragment.newInstance();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.container, fragment);
        //Add to back stack the current fragment
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}
