package com.neopixl.moviequizz.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Score;

import java.util.ArrayList;
import java.util.List;

public class ScoreAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private List<Score> scores;
    private Context context;

    public ScoreAdapter(Context context, List<Score> scores) {
        super();
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.scores = scores;
    }

    public ScoreAdapter(Context context) {
        super();
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.scores = new ArrayList<Score>();
    }

    @Override
    public int getCount() {
        return this.scores.size();
    }

    @Override
    public Object getItem(int position) {
        return this.scores.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View viewFromCache, ViewGroup parent) {
        TextView textViewName = null;
        TextView textViewScore = null;

        if (viewFromCache == null) {
            viewFromCache = layoutInflater.inflate(R.layout.row_highscore, parent, false);

            textViewName = (TextView) viewFromCache.findViewById(R.id.row_highscore_textView_name);
            textViewScore = (TextView) viewFromCache.findViewById(R.id.row_highscore_textView_score);
            viewFromCache.setTag(R.id.row_highscore_textView_name, textViewName);
            viewFromCache.setTag(R.id.row_highscore_textView_score, textViewScore);
        } else {
            textViewName = (TextView) viewFromCache.getTag(R.id.row_highscore_textView_name);
            textViewScore = (TextView) viewFromCache.getTag(R.id.row_highscore_textView_score);
        }


        Score score = scores.get(position);
        if (score != null) {
            textViewName.setText(score.getName());
            textViewScore.setText(score.getScore()+"/"+score.getMaxScore());
            if(score.getScore()>=score.getMaxScore()/2)
                viewFromCache.setBackgroundColor(Color.GREEN);
            else
                viewFromCache.setBackgroundColor(Color.RED);


        }

        return viewFromCache;
    }

    public List<Score> getScores() {
        return scores;
    }

    public void setScores(List<Score> listScore) {
        this.scores = listScore;
        this.notifyDataSetChanged();
    }

    public void addScore(Score score) {
        this.scores.add(score);
        this.notifyDataSetChanged();
    }
}
