package com.neopixl.moviequizz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mikepenz.fastadapter.commons.adapters.FastItemAdapter;
import com.neopixl.moviequizz.App;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.item.CategoryItem;
import com.neopixl.moviequizz.item.ScoreItem;
import com.neopixl.moviequizz.model.Category;
import com.neopixl.moviequizz.model.Score;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static androidx.recyclerview.widget.RecyclerView.VERTICAL;

public class ScoreFragment extends Fragment {
    private List<Score> scores = new ArrayList<>();

    @BindView(R.id.fragment_highscores_recyclerViewScores)
    RecyclerView recyclerView;

    private FastItemAdapter<ScoreItem> adapter = new FastItemAdapter<>();

    public static ScoreFragment newInstance() {
        ScoreFragment fragment = new ScoreFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_highscores, container, false);
        ButterKnife.bind(this, view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), VERTICAL, false));
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        getActivity().setTitle(R.string.fragment_highscores_title);
    }

    @Override
    public void onStart() {
        super.onStart();
        loadScores();
    }

    private void loadScores() {
        scores.clear();
        scores = App.getSharedInstance().getScores();

        for (Score score : scores){
            adapter.add(new ScoreItem(score));
        }
        recyclerView.setAdapter(adapter);
    }
}
