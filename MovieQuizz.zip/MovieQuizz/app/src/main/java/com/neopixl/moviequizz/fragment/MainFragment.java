package com.neopixl.moviequizz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.adapter.CategoryAdapter;
import com.neopixl.moviequizz.model.Category;

import java.util.ArrayList;
import java.util.List;

public class MainFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener {
    ListView categoryListView = null;
    private int containerId;
    private CategoryAdapter adapter;
    private List<Category> categories = new ArrayList<>();

    public static MainFragment newInstance(List<Category> categories)
    {
        MainFragment fragment = new MainFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);
        fragment.categories.clear();
        fragment.categories.addAll(categories);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        containerId = container.getId();
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        categoryListView = (ListView) view.findViewById(R.id.fragment_main_listViewCategory);
        Button btn = (Button) view.findViewById(R.id.fragment_main_btnHighScores);
        btn.setOnClickListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        adapter = new CategoryAdapter(this.getActivity(), this.categories);

        categoryListView.setAdapter(adapter);
        categoryListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapter, View list, int position, long id) {
        Category category = (Category) adapter.getItemAtPosition(position);


        QuestionFragment fragment = QuestionFragment.newInstance(category);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.container, fragment);
        //Add to back stack the current fragment
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public void onClick(View v) {
        ScoreFragment fragment = ScoreFragment.newInstance();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.container, fragment);
        //Add to back stack the current fragment
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}
