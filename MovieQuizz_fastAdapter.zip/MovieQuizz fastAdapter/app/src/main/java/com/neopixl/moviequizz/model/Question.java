package com.neopixl.moviequizz.model;

import io.realm.RealmObject;

public class Question extends RealmObject {

	private String sentence;
	private String answer1;
	private String answer2;
	private String answer3;
	private int correctAnswerNumber;

	public Question() {
	}

	public Question(String sentence, String answer1, String answer2, String answer3, int correctAnswerNumber) {
		this.sentence = sentence;
		this.answer1 = answer1;
		this.answer2 = answer2;
		this.answer3 = answer3;
		this.correctAnswerNumber = correctAnswerNumber;
	}

	public String getSentence() {
		return sentence;
	}

	public void setSentence(String sentence) {
		this.sentence = sentence;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}

	public int getCorrectAnswerNumber() {
		return correctAnswerNumber;
	}

	public void setCorrectAnswerNumber(int correctAnswerNumber) {
		this.correctAnswerNumber = correctAnswerNumber;
	}
}
