package com.neopixl.moviequizz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.neopixl.moviequizz.fragment.MainFragment;
import com.neopixl.moviequizz.model.Category;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Category> categories = new ArrayList<>();
    private MainFragment mainFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadCategories();

        if (savedInstanceState == null) {
            mainFragment = MainFragment.newInstance(categories);
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.add(R.id.container, mainFragment);
            fragmentTransaction.commit();
        }
    }

    private void loadCategories() {
        categories.clear();
        categories = App.getSharedInstance().getCategories();
    }
}