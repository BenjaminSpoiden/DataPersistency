package com.neopixl.moviequizz;

public interface BackPressListener {
    void onBackPressed();
}
