package com.neopixl.moviequizz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.neopixl.moviequizz.App;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.adapter.ScoreAdapter;
import com.neopixl.moviequizz.model.Category;
import com.neopixl.moviequizz.model.Score;

import java.util.ArrayList;
import java.util.List;

public class ScoreFragment extends Fragment {
    private int containerId;
    private Category currentCategory;
    private List<Score> scores = new ArrayList<>();
    private ListView listViewScore;

    public static ScoreFragment newInstance() {
        ScoreFragment fragment = new ScoreFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        containerId = container.getId();
        View view = inflater.inflate(R.layout.fragment_highscores, container, false);
        listViewScore = (ListView) view.findViewById(R.id.fragment_highscores_listViewScores);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        loadScores();
    }

    private void loadScores() {
        scores.clear();
        scores = App.getSharedInstance().getScores();
        ScoreAdapter adapter = new ScoreAdapter(this.getActivity(), this.scores);
        listViewScore.setAdapter(adapter);
    }
}
