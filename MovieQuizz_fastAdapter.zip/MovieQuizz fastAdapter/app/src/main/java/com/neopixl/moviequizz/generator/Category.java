package com.neopixl.moviequizz.generator;

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

public class Category implements Parcelable{
	private String name;
	private ArrayList<Question> questions;

	public Category() {
		questions = new ArrayList<Question>();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<Question> getQuestions() {
		return questions;
	}

	public void addQuestion(Question question) {
		questions.add(question);
	}
	
	public void addQuestions(ArrayList<Question> questions) {
		this.questions.addAll(questions);
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int arg1) {
		parcel.writeString(name);
		parcel.writeList(questions);
	}

	public static final Creator<Category> CREATOR
	= new Creator<Category>() {
		public Category createFromParcel(Parcel in) {
			Category category = new Category();
			category.setName(in.readString());
			ArrayList<Question> questions = new ArrayList<Question>();
			in.readList(questions, Question.class.getClassLoader());
			category.addQuestions(questions);
			
			return category;
		}

		public Category[] newArray(int size) {
			return new Category[size];
		}
	};

}
