package com.neopixl.moviequizz.fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.neopixl.moviequizz.App;
import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Category;

public class ResultFragment extends Fragment implements View.OnClickListener {
    private int containerId;
    private Category currentCategory;
    private int score;
    private int maxQuestions;
    private TextView textViewResult;
    private EditText editTextName;

    private void setScore(int score)
    {
        this.score=score;
    }

    private void setMaxQuestions(int value)
    {
        this.maxQuestions=value;
    }

    private void setCurrentCategory(Category category)
    {
        this.currentCategory=category;
    }

    public static ResultFragment newInstance(Category category, int score, int maxQuestion) {
        ResultFragment fragment = new ResultFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);
        fragment.setCurrentCategory(category);
        fragment.setScore(score);
        fragment.setMaxQuestions(maxQuestion);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        containerId = container.getId();
        View view = inflater.inflate(R.layout.fragment_result, container, false);

        textViewResult = (TextView)view.findViewById(R.id.fragment_result_textViewResult);
        editTextName = (EditText)view.findViewById(R.id.fragment_result_editTextName);
        Button button = (Button)view.findViewById(R.id.fragment_result_btnValid);
        button.setOnClickListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        String txt;
        if(score>=maxQuestions/2) {
            txt=getActivity().getResources().getString(R.string.fragment_result_win);
        }
        else {
            txt=getActivity().getResources().getString(R.string.fragment_result_lose);
        }

        txt = txt.replace("###",score+"/"+maxQuestions);

        textViewResult.setText(txt);
    }

    @Override
    public void onClick(View v) {
        if(editTextName.getText().length()==0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage(getActivity().getResources().getString(R.string.fragment_result_error_desc)).setTitle(getActivity().getResources().getString(R.string.fragment_result_error));
            builder.setPositiveButton("Ok", null);
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {

            App.getSharedInstance().addScore(editTextName.getText().toString(), score, maxQuestions);
            getFragmentManager().popBackStack();
            getFragmentManager().popBackStack();
        }

        closeKeyboard();
    }

    private void closeKeyboard() {
        InputMethodManager inputManager = (InputMethodManager)
                getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
