package com.neopixl.moviequizz;

import android.app.Application;

import com.neopixl.moviequizz.generator.ModelGenerator;
import com.neopixl.moviequizz.generator.Question;
import com.neopixl.moviequizz.model.Category;
import com.neopixl.moviequizz.model.Score;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;

public class App extends Application {
    private static App sharedInstance;
    private Realm realm;

    public static App getSharedInstance() {
        return sharedInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sharedInstance = this;
        initializeDatabase();
    }

    private void initializeDatabase() {
        Realm.init(getApplicationContext());
        realm = Realm.getDefaultInstance();
        if(realm.where(Category.class).count() == 0) {

            realm.beginTransaction();
            for(com.neopixl.moviequizz.generator.Category category : ModelGenerator.generateCategories()) {
                Category catDB = new Category(category.getName());
                catDB.setQuestions(new RealmList<com.neopixl.moviequizz.model.Question>());
                for(Question question: category.getQuestions()) {
                    com.neopixl.moviequizz.model.Question questionDB = new com.neopixl.moviequizz.model.Question(question.getSentence(), question.getAnswer1(), question.getAnswer2(), question.getAnswer3(), question.getCorrectAnswerNumber());
                    catDB.getQuestions().add(questionDB);
                }
                realm.copyToRealm(catDB);
            }
            realm.commitTransaction();
        }
    }

    public List<Category> getCategories() {
        return realm.where(Category.class).findAll();
    }

    public List<Score> getScores() {
        return realm.where(Score.class).findAll();
    }

    public void addScore(String name, int userScore, int maxScore) {
        realm.beginTransaction();
        Score score = realm.createObject(Score.class);
        score.setName(name);
        score.setScore(userScore);
        score.setMaxScore(maxScore);
        realm.commitTransaction();
    }

}
