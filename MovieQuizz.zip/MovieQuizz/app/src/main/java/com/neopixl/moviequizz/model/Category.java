package com.neopixl.moviequizz.model;

import android.os.Parcel;

import java.util.ArrayList;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Category extends RealmObject {
	@PrimaryKey
	private String name;
	private RealmList<Question> questions;

	public Category() {

	}

	public Category(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public RealmList<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(RealmList<Question> questions) {
		this.questions = questions;
	}
}
