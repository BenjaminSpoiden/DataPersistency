package com.neopixl.moviequizz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private List<Category> categories;
    private Context context;

    public CategoryAdapter(Context context, List<Category> categories) {
        super();
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (null != categories) {
            this.categories = categories;
        } else {
            this.categories = new ArrayList<Category>();
        }
    }

    public CategoryAdapter(Context context) {
        super();
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.categories = new ArrayList<Category>();
    }

    @Override
    public int getCount() {
        return this.categories.size();
    }

    @Override
    public Object getItem(int position) {
        return this.categories.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View viewFromCache, ViewGroup parent)
    {
        TextView textViewName = null;
        if(viewFromCache==null) {
            viewFromCache = layoutInflater.inflate(R.layout.row_category,parent,false);
            textViewName = (TextView)viewFromCache.findViewById(R.id.row_category_textView_name);
            viewFromCache.setTag(R.id.row_category_textView_name,textViewName);
        }
        else {
            textViewName = (TextView)viewFromCache.getTag(R.id.row_category_textView_name);
        }

        Category category = categories.get(position);
        if(category!=null) {
            textViewName.setText(category.getName());
        }

        return viewFromCache;
    }

    public List<Category> getCategories()
    {
        return categories;
    }

    public void setCategories(List<Category> listCategory) {
        this.categories = listCategory;
        this.notifyDataSetChanged();
    }

    public void addCategory(Category category) {
        this.categories.add(category);
        this.notifyDataSetChanged();
    }
}
