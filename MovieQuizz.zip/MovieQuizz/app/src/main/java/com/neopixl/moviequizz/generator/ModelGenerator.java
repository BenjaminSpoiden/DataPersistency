package com.neopixl.moviequizz.generator;

import java.util.ArrayList;

public class ModelGenerator {
	
	public static ArrayList<Category> generateCategories() {
		ArrayList<Category> allCategories = new ArrayList<Category>();
		
		Category category1 = new Category();
		category1.setName("Film d'action");
		
		Question question1 = new Question();
		question1.setSentence("Dans le film Commando qui interpr�te la fille du colonel John Matrix ?");
		question1.setAnswer1("Jessica Alba");
		question1.setAnswer2("Alyssa Milano");
		question1.setAnswer3("Halle Berry");
		question1.setCorrectAnswerNumber(2);
		
		category1.addQuestion(question1);
		
		Question question2 = new Question();
		question2.setSentence("Dans le film Speed, o� se trouve la bombe ?");
		question2.setAnswer1("A bord d'un bateau");
		question2.setAnswer2("Dans un train");
		question2.setAnswer3("Dans un bus");
		question2.setCorrectAnswerNumber(3);
		
		category1.addQuestion(question2);
		
		Question question3 = new Question();
		question3.setSentence("Dans le film Pi�ge de Cristal que fait John Mc Clane lorsqu'il arrive au Nakatomi Plaza ?");
		question3.setAnswer1("Il retire sa cravatte");
		question3.setAnswer2("Il retire son alliance");
		question3.setAnswer3("Il retire ses chaussures");
		question3.setCorrectAnswerNumber(3);
		
		category1.addQuestion(question3);
		
		Question question4 = new Question();
		question4.setSentence("Dans le film Rambo, combien de personnes tue John Rambo ?");
		question4.setAnswer1("0");
		question4.setAnswer2("7");
		question4.setAnswer3("18");
		question4.setCorrectAnswerNumber(1);
		
		category1.addQuestion(question4);
		
		allCategories.add(category1);
		
		Category category2 = new Category();
		category2.setName("Com�die");
		
		Question question21 = new Question();
		question21.setSentence("Dans le film Le p�re no�l est une ordure quel est le nom de la patisserie rapport�e par Monsieur Preskovic ?");
		question21.setAnswer1("Les rolopchis");
		question21.setAnswer2("Les carabitchous");
		question21.setAnswer3("Les doubitchous");
		question21.setCorrectAnswerNumber(3);
		
		category2.addQuestion(question21);
		
		Question question22 = new Question();
		question22.setSentence("Dans le film Sos Fant�mes, que ne faut-il surtout par faire  ?");
		question22.setAnswer1("Croiser les effluves");
		question22.setAnswer2("Se promener tard dans les rues de New York");
		question22.setAnswer3("Jouer avec les grille-pain");
		question22.setCorrectAnswerNumber(1);
		
		category2.addQuestion(question22);
		
		Question question23 = new Question();
		question23.setSentence("Dans le film Le corniaud, que dit Bourvil lorsque Louis de fun�s d�truit sa 2CV ?");
		question23.setAnswer1("Ah ben maintenant comment je vais faire !");
		question23.setAnswer2("C'est dommage je n'ai pas d'assurance !");
		question23.setAnswer3("Elle va beaucoup moins bien marcher maintenant !");
		question23.setCorrectAnswerNumber(3);
		
		category2.addQuestion(question23);
		
		Question question24 = new Question();
		question24.setSentence("Qu'est ce qui pousse les goonies � vivre une aventure hors du commun ?");
		question24.setAnswer1("L'arrestation des fr�res fratelli.");
		question24.setAnswer2("La d�couverte d'une carte au tr�sor.");
		question24.setAnswer3("La capture d'un des leurs.");
		question24.setCorrectAnswerNumber(2);
		
		category2.addQuestion(question24);
		

		allCategories.add(category2);
		
		Category category3 = new Category();
		category3.setName("Horreur");
		
		Question question31 = new Question();
		question31.setSentence("Dans le film Halloween : La nuit des masques, que cherche � faire le psychopathe Michael Myers ?");
		question31.setAnswer1("Venger la mort de sa soeur");
		question31.setAnswer2("Tuer sa soeur");
		question31.setAnswer3("Chercher des bonbons");
		question31.setCorrectAnswerNumber(2);
		
		category3.addQuestion(question31);
		
		Question question32 = new Question();
		question32.setSentence("Dans le film Les griffes de la nuit comment s'appelle le tueur ?");
		question32.setAnswer1("Freddy Krueger");
		question32.setAnswer2("Keyser S�ze");
		question32.setAnswer3("Jason Voorhees");
		question32.setCorrectAnswerNumber(3);

		category3.addQuestion(question32);
		
		Question question33 = new Question();
		question33.setSentence("Dans quel film est-il question de t�l�pathie ?");
		question33.setAnswer1("The Shinning");
		question33.setAnswer2("Le sixi�me sens");
		question33.setAnswer3("Hellraiser");
		question33.setCorrectAnswerNumber(1);

		category3.addQuestion(question33);
		
		Question question34 = new Question();
		question34.setSentence("Comment s'appelle le tueur dans le film Psychose ?");
		question34.setAnswer1("Norman Gates");
		question34.setAnswer2("Norman Bates");
		question34.setAnswer3("Phillip Norman");
		question34.setCorrectAnswerNumber(2);

		category3.addQuestion(question34);
		
		allCategories.add(category3);
		
		return allCategories;
	}
}
