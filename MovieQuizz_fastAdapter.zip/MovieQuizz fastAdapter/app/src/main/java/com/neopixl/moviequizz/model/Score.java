package com.neopixl.moviequizz.model;

import io.realm.RealmObject;

public class Score extends RealmObject {

    private String name;
    private int score;
    private int maxScore;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(int maxScore) {
        this.maxScore = maxScore;
    }
}
