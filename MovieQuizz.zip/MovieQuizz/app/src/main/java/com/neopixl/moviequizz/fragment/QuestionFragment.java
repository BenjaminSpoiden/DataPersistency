package com.neopixl.moviequizz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.neopixl.moviequizz.R;
import com.neopixl.moviequizz.model.Category;
import com.neopixl.moviequizz.model.Question;

import java.util.List;

public class QuestionFragment extends Fragment implements View.OnClickListener {
    private int containerId;
    private Category currentCategory;
    private int currentQuestion;
    private int currentScore;
    private List<Question> questions;
    private TextView textViewQuestion;
    private RadioButton radioButtonChoice1;
    private RadioButton radioButtonChoice2;
    private RadioButton radioButtonChoice3;
    private Button buttonNext;

    private void setCurrentCategory(Category category)
    {
        this.currentCategory=category;
    }

    public static QuestionFragment newInstance(Category category) {
        QuestionFragment fragment = new QuestionFragment();
        Bundle arguments = new Bundle();
        fragment.setArguments(arguments);
        fragment.setCurrentCategory(category);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        containerId = container.getId();
        View view = inflater.inflate(R.layout.fragment_question, container, false);

        textViewQuestion = (TextView)view.findViewById(R.id.fragment_question_textViewQuestion);
        radioButtonChoice1 = (RadioButton)view.findViewById(R.id.fragment_question_radioButtonChoice1);
        radioButtonChoice2 = (RadioButton)view.findViewById(R.id.fragment_question_radioButtonChoice2);
        radioButtonChoice3 = (RadioButton)view.findViewById(R.id.fragment_question_radioButtonChoice3);
        buttonNext = (Button)view.findViewById(R.id.fragment_question_buttonNext);
        buttonNext.setOnClickListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        questions = currentCategory.getQuestions();
        loadQuestion();
    }

    private boolean loadQuestion() {
        boolean ret=false;
        if(currentQuestion==questions.size()) {
            ret = true;
        }
        else {
            if (currentQuestion == questions.size() - 1) {
                buttonNext.setText(getActivity().getResources().getString(R.string.fragment_question_btnEnd));
            }
            textViewQuestion.setText(questions.get(currentQuestion).getSentence());
            radioButtonChoice1.setText(questions.get(currentQuestion).getAnswer1());
            radioButtonChoice2.setText(questions.get(currentQuestion).getAnswer2());
            radioButtonChoice3.setText(questions.get(currentQuestion).getAnswer3());
        }
        return ret;
    }

    public QuestionFragment() {
        this.currentQuestion=0;
        this.currentScore=0;
    }

    @Override
    public void onClick(View v) {
        int choice=0;

        if(radioButtonChoice1.isChecked()) {
            choice = 1;
        }
        else if(radioButtonChoice2.isChecked()) {
            choice = 2;
        }
        else if(radioButtonChoice3.isChecked()) {
            choice = 3;
        }

        if(questions.get(currentQuestion).getCorrectAnswerNumber()==choice) {
            currentScore++;
        }

        currentQuestion++;

        resetChoice();

        if(loadQuestion()) {
            ResultFragment fragment = ResultFragment.newInstance(currentCategory, currentScore, questions.size());
            FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
            fragmentTransaction.add(R.id.container, fragment);
            //Add to back stack the current fragment
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
    }

    private void resetChoice() {
        radioButtonChoice1.setChecked(false);
        radioButtonChoice2.setChecked(false);
        radioButtonChoice3.setChecked(false);
    }
}
